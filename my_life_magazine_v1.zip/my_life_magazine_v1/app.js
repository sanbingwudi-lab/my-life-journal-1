const STORE_KEY = "myLifeMagazine.entries.v1";
const PREF_KEY = "myLifeMagazine.prefs.v1";
let entries = [];
let editingId = null;
let pendingPhotos = [];
let layoutIndex = 0;
const layouts = ["magazine", "grid", "timeline", "list"];
const layoutNames = ["杂志封面式", "照片瀑布流式", "时间轴日记式", "简约列表式"];
const $ = id => document.getElementById(id);

function safeRead(key, fallback) {
  try { const raw = localStorage.getItem(key); return raw ? JSON.parse(raw) : fallback; }
  catch { return fallback; }
}
function saveEntries() {
  try { localStorage.setItem(STORE_KEY, JSON.stringify(entries)); return true; }
  catch (e) { toast("保存失败：浏览器存储空间可能不足，请减少照片或先导出备份。"); return false; }
}
function load() {
  entries = safeRead(STORE_KEY, []);
  const prefs = safeRead(PREF_KEY, {});
  layoutIndex = Math.max(0, layouts.indexOf(prefs.layout || "magazine"));
  $("themeSelect").value = prefs.theme || "cream";
  $("customColor").value = prefs.customColor || "#A98768";
  applyTheme(prefs.theme || "cream", prefs.customColor || "#A98768");
  applyLayout();
}
function savePrefs() {
  localStorage.setItem(PREF_KEY, JSON.stringify({
    layout: layouts[layoutIndex], theme: $("themeSelect").value, customColor: $("customColor").value
  }));
}
function applyTheme(theme, customColor) {
  const root = document.documentElement;
  const themes = {
    cream: ["#F7F3EB","#FFFDF8","#302D29","#8C857A","#A98768","#E8E0D5"],
    mono: ["#F4F4F1","#FFFFFF","#252525","#777771","#555A56","#E3E3DF"],
    pink: ["#FBF1F1","#FFFAFA","#382D31","#95858A","#C18E9B","#EEDFE2"],
    green: ["#F0F3EB","#FBFCF7","#293329","#7D897B","#7D9274","#DEE5D7"],
    custom: ["#F7F3EB","#FFFDF8","#302D29","#8C857A",customColor,"#E8E0D5"]
  };
  const vals = themes[theme] || themes.cream;
  ["--bg","--card","--ink","--muted","--accent","--line"].forEach((v,i)=>root.style.setProperty(v, vals[i]));
  $("customColorWrap").classList.toggle("hidden", theme !== "custom");
}
function applyLayout() {
  document.body.classList.remove("layout-magazine","layout-grid","layout-timeline","layout-list");
  document.body.classList.add("layout-" + layouts[layoutIndex]);
  $("layoutButton").title = "当前：" + layoutNames[layoutIndex] + "，点击切换";
  renderHome();
}
function todayISO() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
}
function formatDate(dateString, long=false) {
  if (!dateString) return "";
  const d = new Date(dateString + "T12:00:00");
  return new Intl.DateTimeFormat("zh-CN", long ? {year:"numeric",month:"long",day:"numeric",weekday:"short"} : {month:"short",day:"numeric"}).format(d);
}
function escapeHTML(s="") {
  return String(s).replace(/[&<>"']/g, c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}
function sortedEntries() { return [...entries].sort((a,b)=>(b.date||"").localeCompare(a.date||"") || b.createdAt-a.createdAt); }
function entryMarkup(entry) {
  const photo = entry.photos && entry.photos.length ? `<img class="entry-photo" src="${entry.photos[0]}" alt="生活照片">` : "";
  const title = entry.title ? `<h3 class="entry-title">${escapeHTML(entry.title)}</h3>` : "";
  const body = entry.text ? `<p class="entry-text">${escapeHTML(entry.text)}</p>` : "";
  const more = entry.photos && entry.photos.length > 1 ? `<span class="section-caption">＋${entry.photos.length-1} 张照片</span>` : "";
  return `<article class="entry-card">${photo}<div class="entry-body">
    <div class="entry-date">${escapeHTML(formatDate(entry.date,true))}</div>${title}${body}
    <div class="entry-footer"><span class="section-caption">${entry.photos?.length||0} 张照片 ${entry.favorite?" · 已收藏":""}</span><div class="entry-actions">
    <button class="mini-button ${entry.favorite?"favorite":""}" data-action="favorite" data-id="${entry.id}">${entry.favorite?"♥":"♡"}</button>
    <button class="mini-button" data-action="edit" data-id="${entry.id}">编辑</button>
    <button class="mini-button" data-action="delete" data-id="${entry.id}">删除</button></div></div>${more}
    </div></article>`;
}
function renderHome() {
  const host = $("homeContent");
  const list = sortedEntries();
  if (!list.length) {
    host.innerHTML = `<div class="empty-state"><strong>你的故事，从这里开始。</strong>今天可以写几句话，也可以只留下一张照片。<br>不需要每天记录，慢慢来就好。</div>`;
    return;
  }
  host.innerHTML = `<div class="section-title"><h3>最近的生活</h3><span class="section-caption">${list.length} 条记录</span></div>` + list.map(entryMarkup).join("");
}
function renderRecap() {
  $("statEntries").textContent = entries.length;
  $("statDays").textContent = new Set(entries.map(e=>e.date).filter(Boolean)).size;
  $("statPhotos").textContent = entries.reduce((n,e)=>n+(e.photos?.length||0),0);
  $("statFavorites").textContent = entries.filter(e=>e.favorite).length;
  const list = sortedEntries().slice(0,5);
  $("recapList").innerHTML = list.length ? list.map(entryMarkup).join("") : `<div class="empty-state"><strong>回忆会慢慢积累。</strong>留下第一条记录后，这里就会出现属于你的生活片段。</div>`;
}
function showPage(name) {
  document.querySelectorAll(".page").forEach(p=>p.classList.remove("active"));
  $("page-"+name).classList.add("active");
  document.querySelectorAll(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.page===name));
  if(name==="home") renderHome();
  if(name==="recap") renderRecap();
  window.scrollTo({top:0,behavior:"smooth"});
}
function startNewEntry() {
  editingId = null; pendingPhotos = [];
  $("entryForm").reset(); $("entryDate").value = todayISO();
  $("editorHeading").textContent = "记录一个瞬间";
  $("photoPreview").innerHTML = "";
  showPage("write");
}
function startEdit(id) {
  const e = entries.find(x=>x.id===id); if(!e) return;
  editingId = id; pendingPhotos = [...(e.photos||[])];
  $("entryDate").value = e.date || todayISO();
  $("entryTitle").value = e.title || "";
  $("entryText").value = e.text || "";
  $("entryPhotos").value = "";
  $("editorHeading").textContent = "编辑这段回忆";
  renderPhotoPreview(); showPage("write");
}
function renderPhotoPreview() {
  $("photoPreview").innerHTML = pendingPhotos.map(src=>`<img src="${src}" alt="待保存照片">`).join("");
}
function toast(message) {
  const el=$("toast"); el.textContent=message; el.classList.add("show");
  clearTimeout(toast.timer); toast.timer=setTimeout(()=>el.classList.remove("show"),2600);
}
async function filesToDataURLs(fileList) {
  const files = [...fileList];
  const output=[];
  for(const file of files) {
    if(!file.type.startsWith("image/")) continue;
    if(file.size > 7*1024*1024) { toast("单张照片超过 7MB，建议先压缩后再添加。"); continue; }
    output.push(await new Promise((resolve,reject)=>{
      const reader=new FileReader(); reader.onload=()=>resolve(reader.result); reader.onerror=reject; reader.readAsDataURL(file);
    }));
  }
  return output;
}

document.querySelectorAll(".nav-item").forEach(b=>b.addEventListener("click",()=>{
  if(b.dataset.page==="write") startNewEntry(); else showPage(b.dataset.page);
}));
$("homeAddButton").addEventListener("click",startNewEntry);
$("layoutButton").addEventListener("click",()=>{
  layoutIndex=(layoutIndex+1)%layouts.length; applyLayout(); savePrefs();
  toast("首页布局：" + layoutNames[layoutIndex]);
});
$("entryPhotos").addEventListener("change",async e=>{
  const added=await filesToDataURLs(e.target.files);
  pendingPhotos.push(...added); renderPhotoPreview(); e.target.value="";
});
$("entryForm").addEventListener("submit",e=>{
  e.preventDefault();
  const title=$("entryTitle").value.trim(), text=$("entryText").value.trim(), date=$("entryDate").value || todayISO();
  if(!title && !text && !pendingPhotos.length){toast("写几句话或添加一张照片，再保存吧。");return;}
  const existing=entries.find(x=>x.id===editingId);
  const item={id:editingId||("e"+Date.now()+Math.random().toString(16).slice(2)),date,title,text,photos:pendingPhotos,
    favorite:existing?.favorite||false,createdAt:existing?.createdAt||Date.now(),updatedAt:Date.now()};
  if(editingId) entries=entries.map(x=>x.id===editingId?item:x); else entries.push(item);
  if(saveEntries()){toast("这段生活已保存。");showPage("home");editingId=null;pendingPhotos=[];}
});
$("cancelEdit").addEventListener("click",()=>showPage("home"));
document.addEventListener("click",e=>{
  const btn=e.target.closest("[data-action]"); if(!btn)return;
  const id=btn.dataset.id, action=btn.dataset.action;
  if(action==="edit") startEdit(id);
  if(action==="favorite"){entries=entries.map(x=>x.id===id?{...x,favorite:!x.favorite}:x);saveEntries();renderHome();renderRecap();}
  if(action==="delete" && confirm("确定删除这条记录吗？删除后无法从应用内撤销。")){
    entries=entries.filter(x=>x.id!==id);saveEntries();renderHome();renderRecap();toast("记录已删除。");
  }
});
$("themeSelect").addEventListener("change",()=>{applyTheme($("themeSelect").value,$("customColor").value);savePrefs();});
$("customColor").addEventListener("input",()=>{if($("themeSelect").value==="custom"){applyTheme("custom",$("customColor").value);savePrefs();}});
$("exportButton").addEventListener("click",()=>{
  const data={format:"my-life-magazine-backup",version:1,exportedAt:new Date().toISOString(),entries,prefs:safeRead(PREF_KEY,{})};
  const blob=new Blob([JSON.stringify(data)],{type:"application/json"});
  const url=URL.createObjectURL(blob);const a=document.createElement("a");a.href=url;a.download=`my-life-magazine-backup-${todayISO()}.json`;a.click();URL.revokeObjectURL(url);toast("备份文件已导出，请妥善保存。");
});
$("importFile").addEventListener("change",async e=>{
  const file=e.target.files[0];if(!file)return;
  try{
    const data=JSON.parse(await file.text());
    if(data.format!=="my-life-magazine-backup"||!Array.isArray(data.entries))throw new Error("格式不正确");
    if(!confirm(`备份中有 ${data.entries.length} 条记录。导入将替换当前记录，建议先导出当前备份。继续吗？`))return;
    entries=data.entries;saveEntries();
    if(data.prefs){localStorage.setItem(PREF_KEY,JSON.stringify(data.prefs));load();}
    renderHome();renderRecap();toast("备份恢复完成。");
  }catch(err){toast("无法导入：文件不是有效的生活杂志备份。");}
  finally{e.target.value="";}
});
$("showPrivacy").addEventListener("click",()=>$("privacyDialog").showModal());
$("closePrivacy").addEventListener("click",()=>$("privacyDialog").close());
$("closePrivacyButton").addEventListener("click",()=>$("privacyDialog").close());

$("todayDate").textContent = new Intl.DateTimeFormat("zh-CN",{year:"numeric",month:"long",day:"numeric",weekday:"long"}).format(new Date());
$("entryDate").value=todayISO();
load();

// Show the welcome cover whenever the app is opened; tapping the button enters the journal.
const welcomeScreen = $("welcomeScreen");
$("enterAppButton").addEventListener("click", () => {
  welcomeScreen.classList.add("is-hidden");
  window.setTimeout(() => { welcomeScreen.style.display = "none"; }, 520);
});
